
import React, { useState } from 'react';
import { BusinessProfile } from '../types';
import { Save, Building2, MapPin, Phone, Mail, Hash, Camera } from 'lucide-react';

interface Props {
  profile: BusinessProfile;
  onSave: (updated: BusinessProfile) => void;
}

const BusinessProfileEditor: React.FC<Props> = ({ profile, onSave }) => {
  const [formData, setFormData] = useState<BusinessProfile>(profile);
  const [isEditing, setIsEditing] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setIsEditing(false);
  };

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
      <div className="bg-blue-600 p-6 flex justify-between items-center text-white">
        <div className="flex items-center gap-3">
          <Building2 className="w-6 h-6" />
          <h2 className="text-xl font-bold">Business Profile</h2>
        </div>
        {!isEditing && (
          <button 
            onClick={() => setIsEditing(true)}
            className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-xl text-sm font-bold transition-colors"
          >
            Edit Profile
          </button>
        )}
      </div>

      <div className="p-8">
        {isEditing ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                  <Building2 className="w-4 h-4" /> Business Name
                </label>
                <input
                  name="businessName"
                  value={formData.businessName}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                  <Hash className="w-4 h-4" /> GSTIN
                </label>
                <input
                  name="gstin"
                  value={formData.gstin}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                  <Phone className="w-4 h-4" /> Phone
                </label>
                <input
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                  <Mail className="w-4 h-4" /> Email
                </label>
                <input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                <MapPin className="w-4 h-4" /> Address
              </label>
              <textarea
                name="address"
                value={formData.address}
                onChange={handleChange}
                rows={3}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div className="flex gap-3 pt-4">
              <button 
                type="submit"
                className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 flex items-center justify-center gap-2 transition-all"
              >
                <Save className="w-5 h-5" /> Save Changes
              </button>
              <button 
                type="button"
                onClick={() => {
                  setFormData(profile);
                  setIsEditing(false);
                }}
                className="px-6 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-all"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <div className="grid md:grid-cols-2 gap-8">
            <div className="flex items-center gap-6">
              <div className="relative group">
                <img 
                  src={profile.logoUrl || 'https://picsum.photos/seed/placeholder/200/200'} 
                  alt="Logo" 
                  className="w-24 h-24 rounded-2xl object-cover border-2 border-gray-100"
                />
                <div className="absolute inset-0 bg-black/40 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer">
                  <Camera className="text-white w-6 h-6" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">{profile.businessName}</h3>
                <p className="text-blue-600 font-mono font-bold">{profile.gstin}</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3 text-gray-600">
                <MapPin className="w-5 h-5 text-gray-400 mt-1 flex-shrink-0" />
                <p className="text-sm">{profile.address}</p>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <Phone className="w-5 h-5 text-gray-400 flex-shrink-0" />
                <p className="text-sm">{profile.phone}</p>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <Mail className="w-5 h-5 text-gray-400 flex-shrink-0" />
                <p className="text-sm">{profile.email}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BusinessProfileEditor;
