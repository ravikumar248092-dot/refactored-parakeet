
import React, { useState } from 'react';
import { BusinessProfile } from '../types';
import { Plus, Building2, CheckCircle2, Trash2, Briefcase, Sparkles } from 'lucide-react';
import BusinessProfileEditor from './BusinessProfileEditor';
import { BLANK_PROFILE } from '../constants';

interface Props {
  profiles: BusinessProfile[];
  activeProfileId: string | null;
  onSelect: (id: string) => void;
  onAdd: (profile: BusinessProfile) => void;
  onUpdate: (profile: BusinessProfile) => void;
  onDelete: (id: string) => void;
}

const BusinessManager: React.FC<Props> = ({ profiles, activeProfileId, onSelect, onAdd, onUpdate, onDelete }) => {
  const [isAdding, setIsAdding] = useState(false);

  const handleAddNew = () => {
    const newProfile = { ...BLANK_PROFILE, id: Math.random().toString(36).substr(2, 9) };
    onAdd(newProfile);
    setIsAdding(false);
    onSelect(newProfile.id);
  };

  const activeProfile = profiles.find(p => p.id === activeProfileId);

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-black text-gray-900 flex items-center gap-3">
          <Briefcase className="w-8 h-8 text-blue-600" />
          My Businesses
        </h2>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
        >
          <Plus className="w-5 h-5" /> Add New Business
        </button>
      </div>

      {/* AI Business List Show */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {profiles.map(profile => (
          <div 
            key={profile.id}
            onClick={() => onSelect(profile.id)}
            className={`relative p-6 rounded-[2rem] border-2 transition-all cursor-pointer group ${
              activeProfileId === profile.id 
                ? 'border-blue-600 bg-blue-50/50 shadow-xl shadow-blue-100' 
                : 'border-gray-100 bg-white hover:border-blue-200 hover:shadow-lg'
            }`}
          >
            {activeProfileId === profile.id && (
              <div className="absolute -top-3 -right-3 bg-blue-600 text-white p-1.5 rounded-full shadow-lg">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            )}
            
            <div className="flex items-center gap-4 mb-4">
              <img 
                src={profile.logoUrl || 'https://picsum.photos/seed/biz/100/100'} 
                alt="Logo" 
                className="w-14 h-14 rounded-2xl object-cover border border-gray-100"
              />
              <div className="flex-1 min-w-0">
                <h3 className="font-black text-gray-900 truncate">{profile.businessName || "Unnamed Business"}</h3>
                <p className="text-xs font-bold text-blue-600 uppercase tracking-widest">{profile.gstin || "No GSTIN"}</p>
              </div>
            </div>

            <div className="space-y-2 mb-6">
              <p className="text-xs text-gray-500 line-clamp-2">{profile.address || "No address provided"}</p>
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-gray-100">
              <span className={`text-[10px] font-black uppercase tracking-widest ${activeProfileId === profile.id ? 'text-blue-600' : 'text-gray-400'}`}>
                {activeProfileId === profile.id ? 'Active Profile' : 'Click to Select'}
              </span>
              {profiles.length > 1 && (
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(profile.id); }}
                  className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}

        {isAdding && (
          <div className="p-6 rounded-[2rem] border-2 border-dashed border-blue-300 bg-blue-50/30 flex flex-col items-center justify-center text-center space-y-4 animate-pulse">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>
            <p className="font-bold text-blue-600">Setting up new profile...</p>
            <button onClick={handleAddNew} className="text-sm font-black text-blue-600 underline">Click to Confirm</button>
          </div>
        )}
      </div>

      {activeProfile && (
        <div className="pt-12 border-t border-gray-100">
          <div className="mb-8">
            <h3 className="text-2xl font-black text-gray-900">Edit Active Profile</h3>
            <p className="text-gray-500">Changes here will automatically update the AI Invoice Maker.</p>
          </div>
          <BusinessProfileEditor profile={activeProfile} onSave={onUpdate} />
        </div>
      )}
    </div>
  );
};

export default BusinessManager;
