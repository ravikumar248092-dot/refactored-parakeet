
import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-12 mb-12">
          <div className="col-span-2 lg:col-span-2">
            <span className="text-2xl font-bold text-white mb-6 block">myBillBook</span>
            <p className="text-gray-400 mb-6 max-w-sm">
              India's No.1 GST Billing & Accounting Software. Helping small businesses grow with simple and secure digital tools.
            </p>
            <div className="flex gap-4">
              <Facebook className="w-5 h-5 cursor-pointer hover:text-white" />
              <Twitter className="w-5 h-5 cursor-pointer hover:text-white" />
              <Instagram className="w-5 h-5 cursor-pointer hover:text-white" />
              <Linkedin className="w-5 h-5 cursor-pointer hover:text-white" />
              <Youtube className="w-5 h-5 cursor-pointer hover:text-white" />
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6">Features</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-white">GST Billing</a></li>
              <li><a href="#" className="hover:text-white">Inventory Management</a></li>
              <li><a href="#" className="hover:text-white">E-Invoicing</a></li>
              <li><a href="#" className="hover:text-white">POS Billing</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Company</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-white">About Us</a></li>
              <li><a href="#" className="hover:text-white">Careers</a></li>
              <li><a href="#" className="hover:text-white">Contact Us</a></li>
              <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Resources</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-white">Blog</a></li>
              <li><a href="#" className="hover:text-white">Help Center</a></li>
              <li><a href="#" className="hover:text-white">GST Guide</a></li>
              <li><a href="#" className="hover:text-white">Calculators</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 flex flex-col md:row justify-between items-center gap-4 text-xs text-gray-500">
          <p>© 2024 myBillBook. All rights reserved.</p>
          <div className="flex gap-6">
            <span>Made with ❤️ in India</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
