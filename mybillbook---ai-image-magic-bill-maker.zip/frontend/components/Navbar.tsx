
import React, { useState } from 'react';
import { Menu, X, ChevronDown, User, LogOut } from 'lucide-react';

interface NavbarProps {
  isLoggedIn: boolean;
  onLogin: () => void;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ isLoggedIn, onLogin, onLogout }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-8">
            <div className="flex-shrink-0 flex items-center cursor-pointer">
              <span className="text-2xl font-bold text-blue-600">myBillBook</span>
            </div>
            <div className="hidden md:flex items-center space-x-6">
              <div className="group relative">
                <button className="flex items-center text-gray-600 hover:text-blue-600 font-medium">
                  Features <ChevronDown className="ml-1 w-4 h-4" />
                </button>
              </div>
              <div className="group relative">
                <button className="flex items-center text-gray-600 hover:text-blue-600 font-medium">
                  Solutions <ChevronDown className="ml-1 w-4 h-4" />
                </button>
              </div>
              <a href="#" className="text-gray-600 hover:text-blue-600 font-medium">Pricing</a>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            {isLoggedIn ? (
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-full font-medium">
                  <User className="w-4 h-4" />
                  <span>My Business</span>
                </div>
                <button 
                  onClick={onLogout}
                  className="text-gray-500 hover:text-red-600 p-2 rounded-lg transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <>
                <button onClick={onLogin} className="text-gray-600 hover:text-blue-600 font-medium px-4 py-2">Login</button>
                <button onClick={onLogin} className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-6 py-2 rounded-lg transition-colors">
                  Start Free Billing
                </button>
              </>
            )}
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t px-4 pt-2 pb-6 space-y-2">
          <a href="#" className="block px-3 py-2 text-gray-600 font-medium">Features</a>
          <a href="#" className="block px-3 py-2 text-gray-600 font-medium">Solutions</a>
          <a href="#" className="block px-3 py-2 text-gray-600 font-medium">Pricing</a>
          <div className="pt-4 flex flex-col gap-2">
            {isLoggedIn ? (
              <button onClick={onLogout} className="w-full text-center py-2 text-red-600 font-medium border rounded-lg">Logout</button>
            ) : (
              <>
                <button onClick={onLogin} className="w-full text-center py-2 text-gray-600 font-medium border rounded-lg">Login</button>
                <button onClick={onLogin} className="w-full text-center py-2 bg-orange-500 text-white font-semibold rounded-lg">Start Free Billing</button>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
