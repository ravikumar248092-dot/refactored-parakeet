
import React, { useState } from 'react';
import { FEATURES } from '../constants';
import { FileText, ShoppingCart, Package, AlertTriangle } from 'lucide-react';

const iconMap: Record<string, any> = {
  FileText,
  ShoppingCart,
  Package,
  AlertTriangle
};

const Features: React.FC = () => {
  const [activeTab, setActiveTab] = useState('Billing');
  const tabs = Object.keys(FEATURES);

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            All-in-one billing software to help grow your business
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Powerful features designed to simplify your daily operations and boost productivity.
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="inline-flex p-1 bg-gray-100 rounded-xl">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2.5 rounded-lg font-semibold transition-all ${
                  activeTab === tab 
                    ? 'bg-white text-blue-600 shadow-sm' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {FEATURES[activeTab].map((feature) => {
            const Icon = iconMap[feature.icon];
            return (
              <div key={feature.id} className="group bg-gray-50 rounded-2xl p-8 border border-transparent hover:border-blue-100 hover:bg-white hover:shadow-xl transition-all">
                <div className="flex items-start gap-6">
                  <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Icon className="w-7 h-7" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-gray-600 mb-6">{feature.description}</p>
                    <img 
                      src={feature.image} 
                      alt={feature.title} 
                      className="rounded-xl w-full h-48 object-cover shadow-md"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;
