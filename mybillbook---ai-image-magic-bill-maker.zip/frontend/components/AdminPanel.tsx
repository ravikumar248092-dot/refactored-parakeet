
import React, { useState } from 'react';
import { Users, Activity, Database, Settings, Bell, ShieldAlert, UserPlus, X, CheckCircle2, Trash2, Server, Sparkles, FileText, Package, BrainCircuit, Loader2 } from 'lucide-react';
import { Invoice, CatalogItem, BusinessProfile } from '../types';
import { geminiService } from '../services/geminiService';

interface SystemUser {
  id: string;
  name: string;
  email: string;
  role: string;
  status: 'Online' | 'Offline' | 'Idle';
  location: string;
}

interface AdminPanelProps {
  allInvoices: Invoice[];
  allCatalog: CatalogItem[];
  currentProfile: BusinessProfile;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ allInvoices, allCatalog, currentProfile }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'database' | 'settings'>('users');
  const [users, setUsers] = useState<SystemUser[]>([
    { id: '1', name: 'Rahul S.', email: 'rahul@mbb.in', role: 'Manager', status: 'Online', location: 'Mumbai, IN' },
    { id: '2', name: 'Anita K.', email: 'anita@mbb.in', role: 'Billing Staff', status: 'Idle', location: 'Delhi, IN' },
    { id: '3', name: 'Vikram M.', email: 'vikram@mbb.in', role: 'Inventory Head', status: 'Online', location: 'Bangalore, IN' },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', email: '', role: 'Billing Staff', location: 'Remote' });
  
  // AI Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);

  const stats = [
    { label: 'Total Users', value: users.length.toString(), icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Database Entries', value: (allInvoices.length + allCatalog.length).toString(), icon: Database, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'System Load', value: '12%', icon: Activity, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Security Alerts', value: '0', icon: ShieldAlert, color: 'text-orange-600', bg: 'bg-orange-50' },
  ];

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    const user: SystemUser = {
      id: Math.random().toString(36).substr(2, 9),
      ...newUser,
      status: 'Offline'
    };
    setUsers([...users, user]);
    setNewUser({ name: '', email: '', role: 'Billing Staff', location: 'Remote' });
    setShowAddModal(false);
  };

  const deleteUser = (id: string) => {
    if (confirm("Are you sure you want to remove this user?")) {
      setUsers(users.filter(u => u.id !== id));
    }
  };

  const runAIAnalysis = async () => {
    setIsAnalyzing(true);
    const summary = `
      Business: ${currentProfile.businessName}
      Total Invoices: ${allInvoices.length}
      Total Catalog Items: ${allCatalog.length}
      System Users: ${users.length}
      Active Profile Config: ${JSON.stringify(currentProfile.autoInvoiceConfig)}
    `;
    const report = await geminiService.analyzeSystemData(summary);
    setAiReport(report);
    setIsAnalyzing(false);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Admin Control Center</h1>
          <p className="text-gray-500">Welcome back, Boss. System is running optimally.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setActiveTab('database')}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold transition-all shadow-lg ${
              activeTab === 'database' ? 'bg-purple-600 text-white shadow-purple-100' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Server className="w-5 h-5" /> Database Connect
          </button>
          <button className="p-3 bg-white border border-gray-200 rounded-2xl hover:bg-gray-50 transition-all relative">
            <Bell className="w-6 h-6 text-gray-600" />
            <span className="absolute top-2 right-2 w-3 h-3 bg-red-500 border-2 border-white rounded-full"></span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all">
            <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center mb-4`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">{stat.label}</p>
            <p className="text-2xl font-black text-gray-900 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="flex border-b border-gray-100">
        <button 
          onClick={() => setActiveTab('users')}
          className={`px-8 py-4 font-black text-sm transition-all ${activeTab === 'users' ? 'text-blue-600 border-b-4 border-blue-600' : 'text-gray-400'}`}
        >
          User Management
        </button>
        <button 
          onClick={() => setActiveTab('database')}
          className={`px-8 py-4 font-black text-sm transition-all ${activeTab === 'database' ? 'text-purple-600 border-b-4 border-purple-600' : 'text-gray-400'}`}
        >
          Database Explorer
        </button>
        <button 
          onClick={() => setActiveTab('settings')}
          className={`px-8 py-4 font-black text-sm transition-all ${activeTab === 'settings' ? 'text-gray-900 border-b-4 border-gray-900' : 'text-gray-400'}`}
        >
          System Settings
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {activeTab === 'users' && (
            <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                <h3 className="text-xl font-black text-gray-900">System Users</h3>
                <button 
                  onClick={() => setShowAddModal(true)}
                  className="text-blue-600 font-black text-sm flex items-center gap-2 hover:bg-blue-50 px-4 py-2 rounded-xl transition-all"
                >
                  <UserPlus className="w-4 h-4" /> Add User
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 text-xs font-black text-gray-400 uppercase tracking-widest">
                    <tr>
                      <th className="px-8 py-4">User Details</th>
                      <th className="px-8 py-4">Role</th>
                      <th className="px-8 py-4">Status</th>
                      <th className="px-8 py-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {users.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50 transition-colors group">
                        <td className="px-8 py-4">
                          <div className="font-bold text-gray-900">{user.name}</div>
                          <div className="text-xs text-gray-500">{user.email}</div>
                        </td>
                        <td className="px-8 py-4">
                          <span className="text-sm font-medium text-gray-600 bg-gray-100 px-3 py-1 rounded-full">{user.role}</span>
                        </td>
                        <td className="px-8 py-4">
                          <span className={`flex items-center gap-2 text-sm font-bold ${
                            user.status === 'Online' ? 'text-green-500' : user.status === 'Idle' ? 'text-orange-500' : 'text-gray-400'
                          }`}>
                            <span className={`w-2 h-2 rounded-full bg-current ${user.status === 'Online' ? 'animate-pulse' : ''}`}></span>
                            {user.status}
                          </span>
                        </td>
                        <td className="px-8 py-4 text-right">
                          <button 
                            onClick={() => deleteUser(user.id)}
                            className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'database' && (
            <div className="space-y-6">
              <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm p-8">
                <h3 className="text-xl font-black text-gray-900 mb-6 flex items-center gap-2">
                  <Database className="w-6 h-6 text-purple-600" /> System Data Explorer
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                    <div className="flex items-center gap-3 mb-4">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <h4 className="font-black text-gray-900">Invoices</h4>
                    </div>
                    <p className="text-3xl font-black text-gray-900">{allInvoices.length}</p>
                    <p className="text-sm text-gray-500 mt-1">Total saved in database</p>
                  </div>
                  <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                    <div className="flex items-center gap-3 mb-4">
                      <Package className="w-5 h-5 text-orange-600" />
                      <h4 className="font-black text-gray-900">Catalog Items</h4>
                    </div>
                    <p className="text-3xl font-black text-gray-900">{allCatalog.length}</p>
                    <p className="text-sm text-gray-500 mt-1">Active products/services</p>
                  </div>
                </div>
              </div>

              <div className="bg-indigo-900 rounded-[2.5rem] p-10 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32 blur-3xl"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="p-3 bg-white/10 rounded-2xl">
                      <BrainCircuit className="w-8 h-8 text-indigo-300" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-black">AI System Architect</h3>
                      <p className="text-indigo-200">Generate Setup Store & Optimization Reports</p>
                    </div>
                  </div>
                  
                  {aiReport ? (
                    <div className="bg-white/10 border border-white/20 rounded-3xl p-6 mb-6 animate-fadeIn">
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-xs font-black uppercase tracking-widest text-indigo-300">Boss Report Generated</span>
                        <button onClick={() => setAiReport(null)} className="text-white/50 hover:text-white"><X className="w-4 h-4" /></button>
                      </div>
                      <div className="text-sm leading-relaxed whitespace-pre-wrap text-indigo-50">
                        {aiReport}
                      </div>
                    </div>
                  ) : (
                    <p className="text-indigo-100 mb-8 max-w-md">
                      Let AI analyze all user and admin data to suggest the best "Setup Store" configurations for maximum efficiency.
                    </p>
                  )}

                  <button 
                    onClick={runAIAnalysis}
                    disabled={isAnalyzing}
                    className="bg-white text-indigo-900 px-10 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-indigo-50 transition-all shadow-xl disabled:opacity-50"
                  >
                    {isAnalyzing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                    {aiReport ? 'Regenerate Analysis' : 'AI Generate Setup Store'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="bg-gray-900 rounded-[2.5rem] p-8 text-white space-y-6 h-fit sticky top-24">
          <div className="flex items-center gap-3">
            <Settings className="w-6 h-6 text-blue-400" />
            <h3 className="text-xl font-black">System Settings</h3>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl border border-white/10">
              <span className="text-sm font-bold">Maintenance Mode</span>
              <div className="w-10 h-5 bg-gray-700 rounded-full relative cursor-pointer">
                <div className="absolute left-1 top-1 w-3 h-3 bg-gray-400 rounded-full"></div>
              </div>
            </div>
            <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl border border-white/10">
              <span className="text-sm font-bold">AI Auto-Scaling</span>
              <div className="w-10 h-5 bg-blue-500 rounded-full relative cursor-pointer">
                <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
              </div>
            </div>
            <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl border border-white/10">
              <span className="text-sm font-bold">New User Registration</span>
              <div className="w-10 h-5 bg-blue-500 rounded-full relative cursor-pointer">
                <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
          <button className="w-full py-4 bg-blue-600 hover:bg-blue-700 rounded-2xl font-black transition-all mt-4">
            Save System Config
          </button>
        </div>
      </div>

      {/* Add User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-scaleIn">
            <form onSubmit={handleAddUser} className="p-10">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-black text-gray-900">Add System User</h2>
                <button type="button" onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="space-y-5">
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Full Name</label>
                  <input 
                    required
                    type="text"
                    value={newUser.name}
                    onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none transition-all font-bold"
                    placeholder="e.g. John Doe"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Email Address</label>
                  <input 
                    required
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none transition-all font-bold"
                    placeholder="john@mbb.in"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">System Role</label>
                  <select 
                    value={newUser.role}
                    onChange={(e) => setNewUser({...newUser, role: e.target.value})}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none transition-all font-bold appearance-none"
                  >
                    <option>Billing Staff</option>
                    <option>Inventory Manager</option>
                    <option>Accountant</option>
                    <option>Support Agent</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 mt-10">
                <button 
                  type="submit"
                  className="flex-1 bg-blue-600 text-white font-black py-4 rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5" /> Create User
                </button>
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-6 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
