
import React, { useState, useRef } from 'react';
import { Wand2, Loader2, Sparkles, Upload, FileImage, ArrowLeft, CheckCircle2, Save, X, RefreshCw, MessageSquare, Copy } from 'lucide-react';
import { geminiService } from '../services/geminiService';
import { Invoice, BusinessProfile, CatalogItem } from '../types';
import TravelInvoiceTemplate from './TravelInvoiceTemplate';
import InvoiceEditor from './InvoiceEditor';

interface Props {
  businessProfile: BusinessProfile;
  onSaveInvoice: (invoice: Invoice) => void;
  onUpdateProfile: (updated: BusinessProfile) => void;
  catalog: CatalogItem[];
}

const InvoiceGenerator: React.FC<Props> = ({ businessProfile, onSaveInvoice, onUpdateProfile, catalog }) => {
  const [prompt, setPrompt] = useState('');
  const [refinePrompt, setRefinePrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [detectedBiz, setDetectedBiz] = useState<{ name: string, address: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getNextInvoiceNumber = () => {
    if (businessProfile.autoInvoiceConfig.enabled) {
      return `${businessProfile.autoInvoiceConfig.prefix}${businessProfile.autoInvoiceConfig.nextNumber}`;
    }
    return `INV-${Math.floor(Math.random() * 1000)}`;
  };

  const handleAutoGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    const data = await geminiService.generateInvoiceData(prompt);
    if (data) {
      setInvoice({ 
        ...data, 
        id: Math.random().toString(36).substr(2, 9),
        invoiceNumber: getNextInvoiceNumber()
      });
      setIsEditing(true);
    }
    setIsGenerating(false);
  };

  const handleRefineWithAI = async () => {
    if (!refinePrompt.trim() || !invoice) return;
    setIsRefining(true);
    const updatedData = await geminiService.refineInvoiceWithAI(invoice, refinePrompt);
    if (updatedData) {
      setInvoice({ ...updatedData, id: invoice.id });
      setRefinePrompt('');
    }
    setIsRefining(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsGenerating(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      const result = await geminiService.extractInvoiceFromImage(base64, file.type);
      if (result) {
        setInvoice({ 
          ...result.invoice, 
          id: Math.random().toString(36).substr(2, 9),
          invoiceNumber: getNextInvoiceNumber()
        });
        
        if (result.detectedBusinessName && result.detectedBusinessName !== businessProfile.businessName) {
          setDetectedBiz({ 
            name: result.detectedBusinessName, 
            address: result.detectedAddress || '' 
          });
        }
        setIsEditing(true);
      }
      setIsGenerating(false);
    };
    reader.readAsDataURL(file);
  };

  const handleCloneBusinessIdentity = () => {
    if (detectedBiz) {
      onUpdateProfile({
        ...businessProfile,
        businessName: detectedBiz.name,
        address: detectedBiz.address || businessProfile.address
      });
      setDetectedBiz(null);
      alert("Business Profile updated with AI detected identity!");
    }
  };

  const handleSaveInvoice = (updated: Invoice) => {
    setInvoice(updated);
    setIsEditing(false);
  };

  const handleFinalSave = () => {
    if (invoice) {
      onSaveInvoice(invoice);
      setInvoice(null);
      setPrompt('');
      setDetectedBiz(null);
      alert("Invoice saved successfully!");
    }
  };

  return (
    <div className="space-y-8">
      {!isEditing && !invoice && (
        <div className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-gray-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full -mr-32 -mt-32 opacity-50 blur-3xl"></div>
          
          <div className="relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
              <div className="flex items-center gap-4">
                <div className="p-4 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-200">
                  <Sparkles className="w-8 h-8" />
                </div>
                <div>
                  <h2 className="text-3xl font-black text-gray-900">AI Auto Maker</h2>
                  <p className="text-gray-500 font-medium">Generate professional bills in seconds using AI magic.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileUpload} 
                  className="hidden" 
                  accept="image/*"
                />
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 px-6 py-3 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition-all"
                >
                  <Upload className="w-5 h-5" /> Scan Bill Image
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <label className="block text-sm font-black text-gray-400 uppercase tracking-widest">Describe your sale</label>
              <div className="relative">
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g., Sold 10 units of Cement at 450 each to Ramesh Builders. Add 18% GST."
                  rows={4}
                  className="w-full px-8 py-6 bg-gray-50 border-2 border-gray-100 rounded-[2rem] focus:border-blue-500 focus:ring-0 outline-none transition-all resize-none text-xl font-medium placeholder:text-gray-300"
                />
                <div className="absolute right-4 bottom-4">
                  <button 
                    onClick={handleAutoGenerate}
                    disabled={isGenerating || !prompt}
                    className="px-10 py-4 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-700 disabled:opacity-50 flex items-center gap-3 transition-all shadow-xl shadow-blue-100"
                  >
                    {isGenerating ? <Loader2 className="w-6 h-6 animate-spin" /> : <Wand2 className="w-6 h-6" />}
                    <span>Generate Bill</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {isGenerating && (
        <div className="bg-white p-20 rounded-[3rem] shadow-xl border border-gray-100 flex flex-col items-center justify-center text-center space-y-8">
          <div className="relative">
            <div className="w-24 h-24 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin"></div>
            <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-600 w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-black text-gray-900">AI is working its magic...</h3>
            <p className="text-gray-500 text-lg">Extracting data and preparing your professional invoice.</p>
          </div>
        </div>
      )}

      {isEditing && invoice && (
        <div className="space-y-6">
          {detectedBiz && (
            <div className="bg-orange-50 border-2 border-orange-200 p-6 rounded-[2rem] flex flex-col md:flex-row justify-between items-center gap-4 animate-fadeIn">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center">
                  <Copy className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-black text-orange-900">AI Detected Different Business Identity</p>
                  <p className="text-sm text-orange-700">This bill belongs to: <span className="font-bold">{detectedBiz.name}</span>. Clone this to your profile?</p>
                </div>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={handleCloneBusinessIdentity}
                  className="bg-orange-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-orange-700 transition-all shadow-lg shadow-orange-100"
                >
                  Clone Identity
                </button>
                <button 
                  onClick={() => setDetectedBiz(null)}
                  className="text-orange-400 font-bold hover:text-orange-600"
                >
                  Ignore
                </button>
              </div>
            </div>
          )}
          <InvoiceEditor 
            initialData={invoice} 
            onSave={handleSaveInvoice} 
            onCancel={() => {
              setInvoice(null);
              setIsEditing(false);
              setDetectedBiz(null);
            }} 
            catalog={catalog}
          />
        </div>
      )}

      {!isEditing && invoice && (
        <div className="space-y-6 animate-fadeIn">
          {/* AI Refinement Panel */}
          <div className="bg-indigo-600 p-6 rounded-[2rem] shadow-xl text-white">
            <div className="flex items-center gap-3 mb-4">
              <MessageSquare className="w-6 h-6 text-indigo-200" />
              <h3 className="text-lg font-bold">Refine with AI</h3>
              <span className="text-xs bg-white/20 px-2 py-1 rounded-full uppercase font-black tracking-widest">New</span>
            </div>
            <div className="relative">
              <input 
                type="text"
                value={refinePrompt}
                onChange={(e) => setRefinePrompt(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleRefineWithAI()}
                placeholder="e.g., Change driver name to Raushan Kr or update pickup location..."
                className="w-full bg-white/10 border border-white/20 rounded-2xl px-6 py-4 text-lg placeholder:text-indigo-200 outline-none focus:bg-white/20 transition-all"
              />
              <button 
                onClick={handleRefineWithAI}
                disabled={isRefining || !refinePrompt}
                className="absolute right-2 top-2 bottom-2 px-6 bg-white text-indigo-600 font-bold rounded-xl hover:bg-indigo-50 disabled:opacity-50 flex items-center gap-2 transition-all"
              >
                {isRefining ? <Loader2 className="w-5 h-5 animate-spin" /> : <RefreshCw className="w-5 h-5" />}
                Update
              </button>
            </div>
          </div>

          <div className="flex justify-between items-center bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-2 text-blue-600 font-black hover:bg-blue-50 px-6 py-3 rounded-2xl transition-all"
              >
                <ArrowLeft className="w-5 h-5" /> Edit Details
              </button>
              <div className="h-8 w-px bg-gray-100"></div>
              <div className="flex items-center gap-2 text-green-600 font-black">
                <CheckCircle2 className="w-5 h-5" /> AI Verified
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => { setInvoice(null); setPrompt(''); setDetectedBiz(null); }}
                className="px-6 py-3 text-gray-400 font-bold hover:text-red-500 transition-colors"
              >
                Discard
              </button>
              <button 
                onClick={handleFinalSave}
                className="flex items-center gap-2 px-10 py-3 bg-green-600 text-white font-black rounded-2xl hover:bg-green-700 transition-all shadow-lg shadow-green-100"
              >
                <Save className="w-5 h-5" /> Save & Close
              </button>
            </div>
          </div>
          <TravelInvoiceTemplate invoice={invoice} profile={businessProfile} />
        </div>
      )}
    </div>
  );
};

export default InvoiceGenerator;
