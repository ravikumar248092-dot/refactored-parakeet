
import React, { useState } from 'react';
import { UserPlus, Search, ArrowUpRight, ArrowDownLeft, Wallet, History, Plus, Loader2, Sparkles, CheckCircle2, User, Phone, Mail } from 'lucide-react';
import { Customer, Transaction, LedgerUpdate } from '../types';
import { geminiService } from '../services/geminiService';

const CustomerManagement: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([
    { id: '1', name: 'Ramesh Kumar', phone: '9876543210', email: 'ramesh@example.com', totalDues: 1500, totalPaid: 5000 },
    { id: '2', name: 'Suresh Raina', phone: '9988776655', email: 'suresh@example.com', totalDues: 0, totalPaid: 12000 },
  ]);
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [ledgerPrompt, setLedgerPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCustomer, setNewCustomer] = useState({ name: '', phone: '', email: '' });

  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    const customer: Customer = {
      id: Math.random().toString(36).substr(2, 9),
      ...newCustomer,
      totalDues: 0,
      totalPaid: 0
    };
    setCustomers([...customers, customer]);
    setNewCustomer({ name: '', phone: '', email: '' });
    setShowAddModal(false);
  };

  const processLedgerAI = async () => {
    if (!ledgerPrompt.trim()) return;
    setIsProcessing(true);
    
    const update = await geminiService.parseLedgerEntry(ledgerPrompt);
    
    if (update) {
      // Find existing customer or create new one
      let customer = customers.find(c => c.name.toLowerCase().includes(update.customerName.toLowerCase()));
      
      if (!customer) {
        // Auto-create customer if not found
        const newId = Math.random().toString(36).substr(2, 9);
        customer = {
          id: newId,
          name: update.customerName,
          phone: 'N/A',
          email: 'N/A',
          totalDues: 0,
          totalPaid: 0
        };
        setCustomers(prev => [...prev, customer!]);
      }

      // Update balances
      setCustomers(prev => prev.map(c => {
        if (c.id === customer?.id) {
          const newDues = update.type === 'DUE' 
            ? c.totalDues + update.amount 
            : Math.max(0, c.totalDues - update.amount);
          const newPaid = update.type === 'PAID' 
            ? c.totalPaid + update.amount 
            : c.totalPaid;
          
          return {
            ...c,
            totalDues: newDues,
            totalPaid: newPaid
          };
        }
        return c;
      }));

      // Add transaction record
      const transaction: Transaction = {
        id: Math.random().toString(36).substr(2, 9),
        customerId: customer.id,
        amount: update.amount,
        type: update.type,
        date: new Date().toLocaleDateString(),
        description: update.description
      };
      setTransactions([transaction, ...transactions]);
      setLedgerPrompt('');
    }
    setIsProcessing(false);
  };

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.phone.includes(searchTerm)
  );

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* AI Ledger Input */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-8 rounded-3xl shadow-xl text-white">
        <div className="flex items-center gap-3 mb-6">
          <Sparkles className="w-6 h-6 text-blue-200" />
          <h2 className="text-xl font-bold">Smart Ledger Assistant</h2>
        </div>
        <div className="relative">
          <input 
            type="text"
            value={ledgerPrompt}
            onChange={(e) => setLedgerPrompt(e.target.value)}
            placeholder="e.g., Ramesh paid 500 rupees today"
            className="w-full bg-white/10 border border-white/20 rounded-2xl px-6 py-4 text-lg placeholder:text-blue-200 outline-none focus:bg-white/20 transition-all"
          />
          <button 
            onClick={processLedgerAI}
            disabled={isProcessing || !ledgerPrompt}
            className="absolute right-2 top-2 bottom-2 px-6 bg-white text-blue-600 font-bold rounded-xl hover:bg-blue-50 disabled:opacity-50 flex items-center gap-2 transition-all"
          >
            {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
            Update Ledger
          </button>
        </div>
        <p className="mt-4 text-sm text-blue-100 opacity-80">
          AI will automatically identify the customer and update their Paid/Dues amount.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Customer List */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-black text-gray-900">Customers</h2>
            <button 
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-blue-700 transition-all"
            >
              <UserPlus className="w-5 h-5" /> Add Customer
            </button>
          </div>

          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input 
              type="text"
              placeholder="Search by name or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
            />
          </div>

          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="px-6 py-4 text-xs font-black text-gray-400 uppercase tracking-widest">Customer</th>
                  <th className="px-6 py-4 text-xs font-black text-gray-400 uppercase tracking-widest">Dues</th>
                  <th className="px-6 py-4 text-xs font-black text-gray-400 uppercase tracking-widest">Paid</th>
                  <th className="px-6 py-4 text-xs font-black text-gray-400 uppercase tracking-widest text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredCustomers.map(customer => (
                  <tr key={customer.id} className="hover:bg-gray-50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="font-bold text-gray-900">{customer.name}</div>
                      <div className="text-xs text-gray-500">{customer.phone}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`font-bold ${customer.totalDues > 0 ? 'text-red-500' : 'text-gray-400'}`}>
                        ₹{customer.totalDues.toLocaleString()}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-bold text-green-600">
                        ₹{customer.totalPaid.toLocaleString()}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                        <History className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="space-y-6">
          <h2 className="text-2xl font-black text-gray-900">Recent Activity</h2>
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 space-y-4">
            {transactions.length === 0 ? (
              <div className="text-center py-12 text-gray-400">
                <Wallet className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>No recent transactions</p>
              </div>
            ) : (
              transactions.map(tx => {
                const customer = customers.find(c => c.id === tx.customerId);
                return (
                  <div key={tx.id} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 transition-all">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                      tx.type === 'PAID' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                    }`}>
                      {tx.type === 'PAID' ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-gray-900 truncate">{customer?.name}</div>
                      <div className="text-xs text-gray-500 truncate">{tx.description}</div>
                    </div>
                    <div className={`font-black ${tx.type === 'PAID' ? 'text-green-600' : 'text-red-600'}`}>
                      {tx.type === 'PAID' ? '+' : '-'}₹{tx.amount}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-scaleIn">
            <form onSubmit={handleAddCustomer} className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Add New Customer</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input 
                      required
                      type="text"
                      value={newCustomer.name}
                      onChange={(e) => setNewCustomer({...newCustomer, name: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input 
                      required
                      type="tel"
                      value={newCustomer.phone}
                      onChange={(e) => setNewCustomer({...newCustomer, phone: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Email (Optional)</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input 
                      type="email"
                      value={newCustomer.email}
                      onChange={(e) => setNewCustomer({...newCustomer, email: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
              </div>
              <div className="flex gap-3 mt-8">
                <button 
                  type="submit"
                  className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-all"
                >
                  Save Customer
                </button>
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-6 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerManagement;
