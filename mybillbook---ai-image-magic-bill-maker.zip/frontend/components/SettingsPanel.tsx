
import React, { useState } from 'react';
import { Lock, Package, CreditCard, Hash, Save, Plus, Trash2, QrCode, Building2, Smartphone, Car } from 'lucide-react';
import { BusinessProfile, CatalogItem, TravelFieldConfig } from '../types';

interface Props {
  profile: BusinessProfile;
  onSaveProfile: (updated: BusinessProfile) => void;
  catalog: CatalogItem[];
  onUpdateCatalog: (items: CatalogItem[]) => void;
}

const SettingsPanel: React.FC<Props> = ({ profile, onSaveProfile, catalog, onUpdateCatalog }) => {
  const [activeTab, setActiveTab] = useState<'security' | 'catalog' | 'bank' | 'invoice' | 'travel'>('security');
  
  // Password State
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
  
  // Catalog State
  const [newItem, setNewItem] = useState<Partial<CatalogItem>>({ name: '', price: 0, gstRate: 18, category: 'General' });

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwords.new !== passwords.confirm) {
      alert("Passwords do not match!");
      return;
    }
    alert("Password updated successfully!");
    setPasswords({ current: '', new: '', confirm: '' });
  };

  const handleAddItem = () => {
    if (!newItem.name || !newItem.price) return;
    const item: CatalogItem = {
      id: Math.random().toString(36).substr(2, 9),
      name: newItem.name,
      price: newItem.price,
      gstRate: newItem.gstRate || 18,
      category: newItem.category || 'General'
    };
    onUpdateCatalog([...catalog, item]);
    setNewItem({ name: '', price: 0, gstRate: 18, category: 'General' });
  };

  const removeItem = (id: string) => {
    onUpdateCatalog(catalog.filter(i => i.id !== id));
  };

  const toggleTravelField = (field: keyof TravelFieldConfig) => {
    onSaveProfile({
      ...profile,
      travelFieldConfig: {
        ...profile.travelFieldConfig,
        [field]: !profile.travelFieldConfig[field]
      }
    });
  };

  return (
    <div className="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden animate-fadeIn">
      <div className="flex border-b border-gray-100 overflow-x-auto">
        {[
          { id: 'security', label: 'Security', icon: Lock },
          { id: 'catalog', label: 'Catalog', icon: Package },
          { id: 'bank', label: 'Bank & UPI', icon: CreditCard },
          { id: 'invoice', label: 'Invoice Settings', icon: Hash },
          { id: 'travel', label: 'Travel Fields', icon: Car },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-8 py-5 font-bold text-sm transition-all whitespace-nowrap ${
              activeTab === tab.id ? 'text-blue-600 border-b-4 border-blue-600 bg-blue-50/30' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="p-10">
        {activeTab === 'security' && (
          <form onSubmit={handlePasswordChange} className="max-w-md space-y-6">
            <h3 className="text-xl font-black text-gray-900">Change Password</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Current Password</label>
                <input 
                  type="password" 
                  value={passwords.current}
                  onChange={e => setPasswords({...passwords, current: e.target.value})}
                  className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">New Password</label>
                <input 
                  type="password" 
                  value={passwords.new}
                  onChange={e => setPasswords({...passwords, new: e.target.value})}
                  className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Confirm New Password</label>
                <input 
                  type="password" 
                  value={passwords.confirm}
                  onChange={e => setPasswords({...passwords, confirm: e.target.value})}
                  className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                />
              </div>
            </div>
            <button type="submit" className="bg-blue-600 text-white px-10 py-4 rounded-2xl font-black shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all">
              Update Password
            </button>
          </form>
        )}

        {activeTab === 'catalog' && (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-black text-gray-900">Product/Service Catalog</h3>
              <p className="text-sm text-gray-500 font-medium">{catalog.length} items saved</p>
            </div>
            
            <div className="grid md:grid-cols-4 gap-4 p-6 bg-gray-50 rounded-[2rem] border-2 border-dashed border-gray-200">
              <input 
                placeholder="Item Name"
                value={newItem.name}
                onChange={e => setNewItem({...newItem, name: e.target.value})}
                className="bg-white border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 font-bold"
              />
              <input 
                type="number"
                placeholder="Price"
                value={newItem.price || ''}
                onChange={e => setNewItem({...newItem, price: parseFloat(e.target.value)})}
                className="bg-white border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 font-bold"
              />
              <select 
                value={newItem.gstRate}
                onChange={e => setNewItem({...newItem, gstRate: parseInt(e.target.value)})}
                className="bg-white border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 font-bold"
              >
                <option value={0}>0% GST</option>
                <option value={5}>5% GST</option>
                <option value={12}>12% GST</option>
                <option value={18}>18% GST</option>
                <option value={28}>28% GST</option>
              </select>
              <button 
                onClick={handleAddItem}
                className="bg-blue-600 text-white rounded-xl font-black flex items-center justify-center gap-2 hover:bg-blue-700 transition-all"
              >
                <Plus className="w-5 h-5" /> Add to Catalog
              </button>
            </div>

            <div className="grid gap-4">
              {catalog.map(item => (
                <div key={item.id} className="flex items-center justify-between p-6 bg-white border border-gray-100 rounded-2xl shadow-sm group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                      <Package className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-black text-gray-900">{item.name}</p>
                      <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">{item.category}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-8">
                    <div className="text-right">
                      <p className="font-black text-blue-600">₹{item.price.toLocaleString()}</p>
                      <p className="text-[10px] text-gray-400 font-bold uppercase">{item.gstRate}% GST</p>
                    </div>
                    <button 
                      onClick={() => removeItem(item.id)}
                      className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'bank' && (
          <div className="space-y-10">
            <div className="grid md:grid-cols-2 gap-10">
              <div className="space-y-6">
                <h3 className="text-xl font-black text-gray-900 flex items-center gap-2">
                  <Building2 className="w-6 h-6 text-blue-600" /> Bank Account Details
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Account Holder Name</label>
                    <input 
                      value={profile.bankDetails?.name}
                      onChange={e => onSaveProfile({...profile, bankDetails: {...profile.bankDetails!, name: e.target.value}})}
                      className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">IFSC Code</label>
                      <input 
                        value={profile.bankDetails?.ifsc}
                        onChange={e => onSaveProfile({...profile, bankDetails: {...profile.bankDetails!, ifsc: e.target.value}})}
                        className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Bank Name</label>
                      <input 
                        value={profile.bankDetails?.bankName}
                        onChange={e => onSaveProfile({...profile, bankDetails: {...profile.bankDetails!, bankName: e.target.value}})}
                        className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Account Number</label>
                    <input 
                      value={profile.bankDetails?.accountNo}
                      onChange={e => onSaveProfile({...profile, bankDetails: {...profile.bankDetails!, accountNo: e.target.value}})}
                      className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-xl font-black text-gray-900 flex items-center gap-2">
                  <Smartphone className="w-6 h-6 text-blue-600" /> UPI & QR Settings
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">UPI ID (for Auto QR)</label>
                    <input 
                      placeholder="e.g. business@upi"
                      value={profile.upiId}
                      onChange={e => onSaveProfile({...profile, upiId: e.target.value})}
                      className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                    />
                  </div>
                  {profile.upiId && (
                    <div className="p-6 bg-blue-50 rounded-[2rem] border border-blue-100 flex flex-col items-center text-center space-y-4">
                      <div className="bg-white p-4 rounded-2xl shadow-sm">
                        <img 
                          src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${profile.upiId}&pn=${profile.businessName}`} 
                          alt="UPI QR"
                          className="w-32 h-32"
                        />
                      </div>
                      <p className="text-xs font-bold text-blue-600 uppercase tracking-widest">Auto-Generated Payment QR</p>
                      <p className="text-[10px] text-gray-400">This QR will be automatically connected to your invoices.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'invoice' && (
          <div className="max-w-md space-y-8">
            <h3 className="text-xl font-black text-gray-900">Auto-Invoice Numbering</h3>
            <div className="space-y-6">
              <div className="flex items-center justify-between p-6 bg-gray-50 rounded-2xl border border-gray-100">
                <div>
                  <p className="font-black text-gray-900">Enable Auto-Numbering</p>
                  <p className="text-xs text-gray-500">Automatically increment invoice numbers</p>
                </div>
                <button 
                  onClick={() => onSaveProfile({...profile, autoInvoiceConfig: {...profile.autoInvoiceConfig, enabled: !profile.autoInvoiceConfig.enabled}})}
                  className={`w-12 h-6 rounded-full transition-all relative ${profile.autoInvoiceConfig.enabled ? 'bg-blue-600' : 'bg-gray-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${profile.autoInvoiceConfig.enabled ? 'right-1' : 'left-1'}`}></div>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Invoice Prefix</label>
                  <input 
                    value={profile.autoInvoiceConfig.prefix}
                    onChange={e => onSaveProfile({...profile, autoInvoiceConfig: {...profile.autoInvoiceConfig, prefix: e.target.value}})}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Next Number</label>
                  <input 
                    type="number"
                    value={profile.autoInvoiceConfig.nextNumber}
                    onChange={e => onSaveProfile({...profile, autoInvoiceConfig: {...profile.autoInvoiceConfig, nextNumber: parseInt(e.target.value)}})}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none font-bold"
                  />
                </div>
              </div>
              
              <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100">
                <p className="text-xs font-bold text-blue-600 uppercase tracking-widest mb-1">Preview</p>
                <p className="text-2xl font-black text-blue-900">{profile.autoInvoiceConfig.prefix}{profile.autoInvoiceConfig.nextNumber}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'travel' && (
          <div className="max-w-2xl space-y-8">
            <div className="flex items-center gap-3">
              <Car className="w-8 h-8 text-blue-600" />
              <h3 className="text-xl font-black text-gray-900">Travel Field Visibility</h3>
            </div>
            <p className="text-gray-500 font-medium">Toggle which travel-specific fields should appear on your generated invoices. If a field is disabled or left empty, it will not be shown on the bill.</p>
            
            <div className="grid gap-4">
              {[
                { id: 'showDateOfJourney', label: 'Date Of Journey' },
                { id: 'showDriverName', label: 'Driver Name' },
                { id: 'showPickupLocation', label: 'Pickup Location' },
                { id: 'showDropLocation', label: 'Drop Location' },
                { id: 'showTripType', label: 'Trip Type (Round/One-way)' },
                { id: 'showCabNumber', label: 'Cab Number' },
              ].map(field => (
                <div key={field.id} className="flex items-center justify-between p-6 bg-gray-50 rounded-2xl border border-gray-100">
                  <span className="font-bold text-gray-700">{field.label}</span>
                  <button 
                    onClick={() => toggleTravelField(field.id as keyof TravelFieldConfig)}
                    className={`w-12 h-6 rounded-full transition-all relative ${profile.travelFieldConfig[field.id as keyof TravelFieldConfig] ? 'bg-blue-600' : 'bg-gray-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${profile.travelFieldConfig[field.id as keyof TravelFieldConfig] ? 'right-1' : 'left-1'}`}></div>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SettingsPanel;
