
import React from 'react';
import { Power, ShieldCheck, User } from 'lucide-react';

interface StatusSwitchProps {
  isAdmin: boolean;
  onToggle: () => void;
}

const StatusSwitch: React.FC<StatusSwitchProps> = ({ isAdmin, onToggle }) => {
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[100]">
      <div className="bg-white/80 backdrop-blur-md border border-gray-200 rounded-full p-1.5 shadow-2xl flex items-center gap-2">
        <div className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-500 ${!isAdmin ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-500'}`}>
          <User className="w-4 h-4" />
          <span className="text-xs font-bold uppercase tracking-wider">User Mode</span>
        </div>
        
        <button 
          onClick={onToggle}
          className={`relative w-14 h-8 rounded-full transition-colors duration-300 focus:outline-none ${isAdmin ? 'bg-green-500' : 'bg-gray-300'}`}
        >
          <div className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-300 flex items-center justify-center ${isAdmin ? 'translate-x-6' : 'translate-x-0'}`}>
            <Power className={`w-3 h-3 ${isAdmin ? 'text-green-600' : 'text-gray-400'}`} />
          </div>
        </button>

        <div className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-500 ${isAdmin ? 'bg-green-600 text-white shadow-lg' : 'text-gray-500'}`}>
          <ShieldCheck className="w-4 h-4" />
          <span className="text-xs font-bold uppercase tracking-wider">Admin Mode</span>
        </div>
      </div>
    </div>
  );
};

export default StatusSwitch;
