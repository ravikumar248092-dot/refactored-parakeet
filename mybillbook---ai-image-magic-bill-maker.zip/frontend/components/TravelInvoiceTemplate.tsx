
import React from 'react';
import { Invoice, BusinessProfile } from '../types';
import { CheckCircle2, Printer, Download, QrCode } from 'lucide-react';

interface Props {
  invoice: Invoice;
  profile: BusinessProfile;
}

const TravelInvoiceTemplate: React.FC<Props> = ({ invoice, profile }) => {
  const travel = invoice.travelDetails || {};
  const config = profile.travelFieldConfig;

  // Helper to check if a field should be shown
  const shouldShow = (configKey: keyof typeof config, value?: string) => {
    return config[configKey] && value && value.trim() !== "" && value.trim() !== "N/A";
  };

  const hasTravelInfo = 
    shouldShow('showDateOfJourney', travel.dateOfJourney) ||
    shouldShow('showDriverName', travel.driverName) ||
    shouldShow('showPickupLocation', travel.pickupLocation) ||
    shouldShow('showDropLocation', travel.dropLocation) ||
    shouldShow('showTripType', travel.tripType) ||
    shouldShow('showCabNumber', travel.cabNumber);

  return (
    <div className="bg-white shadow-2xl border border-gray-200 max-w-[800px] mx-auto my-8 font-sans text-[12px] leading-tight">
      {/* Top Header Bar */}
      <div className="flex justify-between items-center px-4 py-1 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className="font-bold text-gray-600 uppercase">Bill of Supply</span>
          <span className="bg-gray-100 px-2 py-0.5 rounded text-[10px] text-gray-500">ORIGINAL FOR RECIPIENT</span>
        </div>
        <div className="text-gray-600 italic">Your Traveling Companion , आपकी यात्रा का साथी</div>
      </div>

      {/* Business Info Section */}
      <div className="p-4 flex gap-6">
        <div className="w-24 h-24 flex-shrink-0 relative">
          {profile.logoUrl ? (
            <img src={profile.logoUrl} alt="Logo" className="w-full h-full rounded-full object-cover border-2 border-green-500" />
          ) : (
            <div className="w-full h-full bg-green-500 rounded-full flex items-center justify-center">
              <CheckCircle2 className="text-white w-16 h-16" />
            </div>
          )}
          <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5">
            <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
            </div>
          </div>
        </div>
        <div className="flex-1">
          <h1 className="text-2xl font-black text-gray-900 mb-1">{profile.businessName || "BUSINESS NAME"}</h1>
          <p className="text-gray-600 max-w-md mb-2">{profile.address || "Address not set"}</p>
          <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 text-gray-700">
            <div><span className="font-bold">Mobile:</span> {profile.phone}</div>
            <div><span className="font-bold">GSTIN:</span> {profile.gstin}</div>
            <div><span className="font-bold">PAN Number:</span> {profile.panNumber}</div>
            <div><span className="font-bold">Email:</span> {profile.email}</div>
            <div className="col-span-2"><span className="font-bold">MSME:</span> {profile.msmeNumber}</div>
          </div>
        </div>
      </div>

      {/* Invoice Meta Bar */}
      <div className="bg-[#fdf8e4] px-4 py-2 flex justify-between border-y border-gray-200">
        <div><span className="font-bold">Invoice No.:</span> {invoice.invoiceNumber}</div>
        <div><span className="font-bold">Invoice Date:</span> {invoice.date}</div>
      </div>

      {/* Bill To / Ship To / Trip Details */}
      <div className="grid grid-cols-3 border-b border-gray-200">
        <div className="p-4 border-r border-gray-200">
          <div className="font-bold text-gray-500 mb-1 uppercase text-[10px]">Bill To</div>
          <div className="font-bold text-gray-900">{invoice.customerName}</div>
          <div className="text-gray-600">Place of Supply: Jharkhand</div>
        </div>
        <div className="p-4 border-r border-gray-200">
          <div className="font-bold text-gray-500 mb-1 uppercase text-[10px]">Ship To</div>
          <div className="font-bold text-gray-900">{invoice.customerName}</div>
        </div>
        <div className="p-4 bg-white">
          {hasTravelInfo ? (
            <div className="grid grid-cols-2 gap-y-1">
              {shouldShow('showDateOfJourney', travel.dateOfJourney) && (
                <><div className="font-bold">Date Of Journey</div><div className="text-right">{travel.dateOfJourney}</div></>
              )}
              {shouldShow('showDriverName', travel.driverName) && (
                <><div className="font-bold">Driver Name</div><div className="text-right uppercase">{travel.driverName}</div></>
              )}
              {shouldShow('showPickupLocation', travel.pickupLocation) && (
                <><div className="font-bold">Pickup Location</div><div className="text-right uppercase">{travel.pickupLocation}</div></>
              )}
              {shouldShow('showDropLocation', travel.dropLocation) && (
                <><div className="font-bold">DROP LOCATION</div><div className="text-right text-[10px] leading-none uppercase">{travel.dropLocation}</div></>
              )}
              {shouldShow('showTripType', travel.tripType) && (
                <><div className="font-bold mt-2">TRIP</div><div className="text-right mt-2 uppercase">{travel.tripType}</div></>
              )}
              {shouldShow('showCabNumber', travel.cabNumber) && (
                <><div className="font-bold">CAB NUMBER</div><div className="text-right uppercase">{travel.cabNumber}</div></>
              )}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-300 italic">No travel details provided</div>
          )}
        </div>
      </div>

      {/* Items Table */}
      <div className="min-h-[200px]">
        <table className="w-full">
          <thead className="bg-[#fdf8e4] border-b border-gray-200">
            <tr>
              <th className="px-4 py-2 text-left uppercase font-bold">Items/Services</th>
              <th className="px-4 py-2 text-center uppercase font-bold">Qty.</th>
              <th className="px-4 py-2 text-right uppercase font-bold">Rate</th>
              <th className="px-4 py-2 text-right uppercase font-bold">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {invoice.items.map((item, idx) => (
              <tr key={idx}>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center">
                      <img src="https://picsum.photos/seed/car/32/32" alt="car" className="rounded" />
                    </div>
                    <div className="font-bold uppercase">{item.description}</div>
                  </div>
                </td>
                <td className="px-4 py-3 text-center">{item.quantity} PCS</td>
                <td className="px-4 py-3 text-right">{item.price.toLocaleString()}</td>
                <td className="px-4 py-3 text-right font-bold">{ (item.quantity * item.price).toLocaleString() }</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Subtotal Bar */}
      <div className="bg-[#fdf8e4] px-4 py-2 flex justify-between border-y border-gray-200 font-bold">
        <div className="uppercase">Subtotal</div>
        <div className="flex gap-12">
          <div>{invoice.items.reduce((acc, i) => acc + i.quantity, 0)}</div>
          <div>₹ {invoice.totalAmount.toLocaleString()}</div>
        </div>
      </div>

      {/* Footer Section */}
      <div className="p-4 grid grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="font-bold text-gray-500 uppercase text-[10px] mb-1">Bank Details</div>
              <div className="text-[11px] space-y-0.5">
                <div><span className="font-bold">Name:</span> {profile.bankDetails?.name}</div>
                <div><span className="font-bold">IFSC Code:</span> {profile.bankDetails?.ifsc}</div>
                <div><span className="font-bold">Account No:</span> {profile.bankDetails?.accountNo}</div>
                <div><span className="font-bold">Bank:</span> {profile.bankDetails?.bankName}</div>
              </div>
            </div>
            {profile.upiId && (
              <div className="w-24 text-center">
                <div className="font-bold text-gray-500 uppercase text-[10px] mb-1">Scan to Pay</div>
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=upi://pay?pa=${profile.upiId}&pn=${profile.businessName}&am=${invoice.totalAmount}`} 
                  alt="UPI QR"
                  className="w-20 h-20 mx-auto border border-gray-100 p-1"
                />
                <div className="text-[8px] font-bold text-blue-600 mt-1">{profile.upiId}</div>
              </div>
            )}
          </div>
          <div>
            <div className="font-bold text-gray-500 uppercase text-[10px] mb-1">Terms and Conditions</div>
            <p className="text-[9px] text-gray-600 leading-tight">
              1. A cancellation charge of 15% of the booking amount or the advance amount, whichever is less, is applicable if a booking is canceled between 4 and 24 hours before the scheduled pickup date and time.
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between border-b border-gray-100 pb-1">
            <span className="font-bold">Total Amount</span>
            <span className="font-bold">₹ {invoice.totalAmount.toLocaleString()}</span>
          </div>
          <div className="flex justify-between border-b border-gray-100 pb-1">
            <span className="text-gray-600">Received Amount</span>
            <span className="font-bold">₹ {(invoice.receivedAmount || invoice.totalAmount).toLocaleString()}</span>
          </div>
          <div className="flex justify-between border-b border-gray-100 pb-1">
            <span className="text-gray-600">Balance</span>
            <span className="font-bold">₹ {(invoice.balanceAmount || 0).toLocaleString()}</span>
          </div>
          
          <div className="pt-4 text-right">
            <div className="text-[10px] font-bold text-gray-500 uppercase">Total Amount (in words)</div>
            <div className="text-blue-600 font-bold italic">Amount verified by AI</div>
          </div>
        </div>
      </div>

      {/* Signature Section */}
      <div className="p-8 flex justify-between items-end">
        <div className="w-24 h-24 opacity-20">
          <CheckCircle2 className="w-full h-full text-blue-600" />
        </div>
        <div className="text-center">
          <div className="font-bold uppercase text-[10px] mb-12">Authorised Signatory For</div>
          <div className="font-bold uppercase">{profile.businessName}</div>
        </div>
      </div>

      {/* Action Buttons (Not part of print) */}
      <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-end gap-3 print:hidden">
        <button className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg transition-all">
          <Printer className="w-4 h-4" /> Print
        </button>
        <button className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-all">
          <Download className="w-4 h-4" /> Download PDF
        </button>
      </div>
    </div>
  );
};

export default TravelInvoiceTemplate;
