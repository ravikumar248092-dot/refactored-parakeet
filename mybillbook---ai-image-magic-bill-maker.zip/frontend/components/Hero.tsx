
import React from 'react';
import { CheckCircle, ArrowRight, Play } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-blue-50 to-white pt-16 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight">
              Best GST Billing Software for <span className="text-blue-600">Small Business</span> in India
            </h1>
            <ul className="space-y-4">
              {[
                "Create GST bill in 8 seconds",
                "Increase stock rotation 2.8x faster",
                "Collect 97% payments on time"
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3 text-lg text-gray-700">
                  <CheckCircle className="text-green-500 w-6 h-6 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-orange-500 hover:bg-orange-600 text-white text-lg font-bold px-8 py-4 rounded-xl flex items-center justify-center gap-2 transition-all transform hover:scale-105 shadow-lg">
                Start Free Billing <ArrowRight className="w-5 h-5" />
              </button>
              <button className="border-2 border-orange-500 text-orange-500 hover:bg-orange-50 font-bold px-8 py-4 rounded-xl transition-all">
                Book Free Demo
              </button>
            </div>
            <p className="text-gray-500 font-medium">Trusted by 1 Crore+ Businesses</p>
          </div>
          
          <div className="relative">
            <div className="bg-white p-4 rounded-3xl shadow-2xl border border-gray-100">
              <div className="relative aspect-video rounded-2xl overflow-hidden bg-gray-900 group cursor-pointer">
                <img 
                  src="https://picsum.photos/seed/dashboard/800/450" 
                  alt="Software Dashboard" 
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                    <Play className="text-orange-500 fill-orange-500 w-8 h-8 ml-1" />
                  </div>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-blue-100 rounded-full -z-10 blur-2xl"></div>
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-orange-100 rounded-full -z-10 blur-2xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
