
import React from 'react';
import { Invoice } from '../types';
import { FileText, Trash2, Eye, Calendar, User, IndianRupee } from 'lucide-react';

interface Props {
  invoices: Invoice[];
  onDelete: (id: string) => void;
  onView: (invoice: Invoice) => void;
}

const InvoiceList: React.FC<Props> = ({ invoices, onDelete, onView }) => {
  if (invoices.length === 0) {
    return (
      <div className="bg-white p-12 rounded-3xl border border-gray-100 text-center space-y-4">
        <div className="w-20 h-20 bg-gray-50 text-gray-300 rounded-full flex items-center justify-center mx-auto">
          <FileText className="w-10 h-10" />
        </div>
        <h3 className="text-xl font-bold text-gray-900">No Invoices Found</h3>
        <p className="text-gray-500">Start by creating a new bill in the Dashboard.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      <h2 className="text-2xl font-black text-gray-900">Saved Invoices</h2>
      <div className="grid gap-4">
        {invoices.map((invoice) => (
          <div 
            key={invoice.id}
            className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-gray-900">{invoice.invoiceNumber}</h4>
                <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                  <span className="flex items-center gap-1"><User className="w-3 h-3" /> {invoice.customerName}</span>
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {invoice.date}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between md:justify-end gap-6">
              <div className="text-right">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total</p>
                <p className="text-lg font-black text-blue-600 flex items-center justify-end">
                  <IndianRupee className="w-4 h-4" /> {invoice.totalAmount.toLocaleString()}
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => onView(invoice)}
                  className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                  title="View"
                >
                  <Eye className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => onDelete(invoice.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                  title="Delete"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InvoiceList;
