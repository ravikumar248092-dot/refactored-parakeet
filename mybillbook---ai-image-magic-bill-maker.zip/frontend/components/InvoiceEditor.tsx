
import React, { useState, useEffect } from 'react';
import { Invoice, LineItem, CatalogItem } from '../types';
import { Save, Plus, Trash2, Calculator, Calendar, User, MapPin, Car, Package } from 'lucide-react';

interface Props {
  initialData: Invoice;
  onSave: (updated: Invoice) => void;
  onCancel: () => void;
  catalog: CatalogItem[];
}

const InvoiceEditor: React.FC<Props> = ({ initialData, onSave, onCancel, catalog }) => {
  // Ensure items is always an array even if initialData.items is missing
  const [invoice, setInvoice] = useState<Invoice>({
    ...initialData,
    items: initialData.items || []
  });

  const handleFieldChange = (field: keyof Invoice, value: any) => {
    setInvoice(prev => ({ ...prev, [field]: value }));
  };

  const handleTravelChange = (field: string, value: any) => {
    setInvoice(prev => ({
      ...prev,
      travelDetails: { ...prev.travelDetails, [field]: value }
    }));
  };

  const handleItemChange = (index: number, field: keyof LineItem, value: any) => {
    const newItems = [...(invoice.items || [])];
    newItems[index] = { ...newItems[index], [field]: value };
    setInvoice(prev => ({ ...prev, items: newItems }));
  };

  const handleCatalogSelect = (index: number, catalogId: string) => {
    const selected = catalog.find(i => i.id === catalogId);
    if (selected) {
      const newItems = [...(invoice.items || [])];
      newItems[index] = {
        ...newItems[index],
        description: selected.name,
        price: selected.price,
        gstRate: selected.gstRate
      };
      setInvoice(prev => ({ ...prev, items: newItems }));
    }
  };

  const addItem = () => {
    setInvoice(prev => ({
      ...prev,
      items: [...(prev.items || []), { description: '', quantity: 1, price: 0, gstRate: 0 }]
    }));
  };

  const removeItem = (index: number) => {
    setInvoice(prev => ({
      ...prev,
      items: (prev.items || []).filter((_, i) => i !== index)
    }));
  };

  // Auto-calculate totals
  useEffect(() => {
    const items = invoice.items || [];
    const subtotal = items.reduce((acc, item) => acc + (item.quantity * item.price), 0);
    const gst = items.reduce((acc, item) => acc + (item.quantity * item.price * (item.gstRate / 100)), 0);
    const total = subtotal + gst;
    
    if (total !== invoice.totalAmount || gst !== invoice.totalGst) {
      setInvoice(prev => ({
        ...prev,
        totalAmount: total,
        totalGst: gst,
        balanceAmount: total - (prev.receivedAmount || 0)
      }));
    }
  }, [invoice.items, invoice.receivedAmount]);

  return (
    <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden animate-slideUp">
      <div className="bg-gray-900 p-6 flex justify-between items-center text-white">
        <div className="flex items-center gap-3">
          <Calculator className="w-6 h-6 text-blue-400" />
          <h2 className="text-xl font-bold">Full Panel AI Editor</h2>
        </div>
        <div className="flex gap-3">
          <button onClick={onCancel} className="px-4 py-2 text-gray-400 hover:text-white transition-colors">Cancel</button>
          <button 
            onClick={() => onSave(invoice)}
            className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded-xl font-bold flex items-center gap-2 transition-all"
          >
            <Save className="w-4 h-4" /> Save & Preview
          </button>
        </div>
      </div>

      <div className="p-8 space-y-10 max-h-[80vh] overflow-y-auto">
        {/* Basic Info */}
        <section className="grid md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <User className="w-3 h-3" /> Customer Name
            </label>
            <input 
              value={invoice.customerName || ''}
              onChange={(e) => handleFieldChange('customerName', e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Calendar className="w-3 h-3" /> Invoice Date
            </label>
            <input 
              value={invoice.date || ''}
              onChange={(e) => handleFieldChange('date', e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
              # Invoice Number
            </label>
            <input 
              value={invoice.invoiceNumber || ''}
              onChange={(e) => handleFieldChange('invoiceNumber', e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </section>

        {/* Travel Details */}
        <section className="bg-blue-50/50 p-6 rounded-3xl border border-blue-100">
          <h3 className="text-sm font-black text-blue-600 uppercase tracking-widest mb-6 flex items-center gap-2">
            <Car className="w-4 h-4" /> Travel & Trip Details
          </h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Driver Name</label>
              <input 
                value={invoice.travelDetails?.driverName || ''}
                onChange={(e) => handleTravelChange('driverName', e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Cab Number</label>
              <input 
                value={invoice.travelDetails?.cabNumber || ''}
                onChange={(e) => handleTravelChange('cabNumber', e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Trip Type</label>
              <input 
                value={invoice.travelDetails?.tripType || ''}
                onChange={(e) => handleTravelChange('tripType', e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Total KM</label>
              <input 
                value={invoice.travelDetails?.totalKm || ''}
                onChange={(e) => handleTravelChange('totalKm', e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
              />
            </div>
            <div className="md:col-span-2 space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                <MapPin className="w-3 h-3" /> Pickup Location
              </label>
              <input 
                value={invoice.travelDetails?.pickupLocation || ''}
                onChange={(e) => handleTravelChange('pickupLocation', e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
              />
            </div>
            <div className="md:col-span-2 space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                <MapPin className="w-3 h-3" /> Drop Location
              </label>
              <input 
                value={invoice.travelDetails?.dropLocation || ''}
                onChange={(e) => handleTravelChange('dropLocation', e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
              />
            </div>
          </div>
        </section>

        {/* Items Table */}
        <section>
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest">Items & Services</h3>
            <button 
              onClick={addItem}
              className="flex items-center gap-2 text-blue-600 font-bold hover:bg-blue-50 px-4 py-2 rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" /> Add Item
            </button>
          </div>
          <div className="space-y-4">
            {(invoice.items || []).map((item, idx) => (
              <div key={idx} className="grid md:grid-cols-12 gap-4 items-end bg-gray-50 p-4 rounded-2xl border border-gray-100 group">
                <div className="md:col-span-4 space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase">Description</label>
                  <div className="flex gap-2">
                    <input 
                      value={item.description || ''}
                      onChange={(e) => handleItemChange(idx, 'description', e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
                    />
                    {catalog.length > 0 && (
                      <select 
                        onChange={(e) => handleCatalogSelect(idx, e.target.value)}
                        className="w-10 px-1 bg-white border border-gray-200 rounded-lg outline-none text-[10px]"
                        value=""
                      >
                        <option value="" disabled>📦</option>
                        {catalog.map(cat => (
                          <option key={cat.id} value={cat.id}>{cat.name}</option>
                        ))}
                      </select>
                    )}
                  </div>
                </div>
                <div className="md:col-span-1 space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase">Qty</label>
                  <input 
                    type="number"
                    value={item.quantity || 0}
                    onChange={(e) => handleItemChange(idx, 'quantity', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
                  />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase">Rate</label>
                  <input 
                    type="number"
                    value={item.price || 0}
                    onChange={(e) => handleItemChange(idx, 'price', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
                  />
                </div>
                <div className="md:col-span-1 space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase">GST %</label>
                  <input 
                    type="number"
                    value={item.gstRate || 0}
                    onChange={(e) => handleItemChange(idx, 'gstRate', parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none"
                  />
                </div>
                <div className="md:col-span-3 space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase">Total</label>
                  <div className="px-3 py-2 bg-gray-100 border border-gray-200 rounded-lg font-bold text-gray-600">
                    ₹{((item.quantity || 0) * (item.price || 0) * (1 + (item.gstRate || 0)/100)).toLocaleString()}
                  </div>
                </div>
                <div className="md:col-span-1 pb-1">
                  <button 
                    onClick={() => removeItem(idx)}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Totals & Payment */}
        <section className="flex flex-col md:flex-row justify-end gap-8 pt-8 border-t border-gray-100">
          <div className="w-full md:w-80 space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-500 font-bold">Received Amount</span>
              <input 
                type="number"
                value={invoice.receivedAmount || 0}
                onChange={(e) => handleFieldChange('receivedAmount', parseFloat(e.target.value) || 0)}
                className="w-32 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-right font-bold outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex justify-between items-center text-xl font-black text-gray-900 pt-4 border-t border-gray-200">
              <span>Grand Total</span>
              <span className="text-blue-600">₹{(invoice.totalAmount || 0).toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center text-sm font-bold text-red-500">
              <span>Balance Due</span>
              <span>₹{((invoice.totalAmount || 0) - (invoice.receivedAmount || 0)).toLocaleString()}</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default InvoiceEditor;
