
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import ChatAssistant from './components/ChatAssistant';
import InvoiceGenerator from './components/InvoiceGenerator';
import BusinessProfileEditor from './components/BusinessProfileEditor';
import CustomerManagement from './components/CustomerManagement';
import InvoiceList from './components/InvoiceList';
import TravelInvoiceTemplate from './components/TravelInvoiceTemplate';
import AdminPanel from './components/AdminPanel';
import StatusSwitch from './components/StatusSwitch';
import SettingsPanel from './components/SettingsPanel';
import { LogIn, X, LayoutDashboard, UserCircle, FileText, Settings, Users, ArrowLeft, ShieldCheck, Lock, UserPlus } from 'lucide-react';
import { BusinessProfile, Invoice, CatalogItem } from './types';
import { DEFAULT_PROFILE, BLANK_PROFILE } from './constants';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginType, setLoginType] = useState<'user' | 'admin' | 'register'>('user');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'profile' | 'customers' | 'invoices' | 'admin' | 'settings'>('dashboard');
  const [businessProfile, setBusinessProfile] = useState<BusinessProfile>(DEFAULT_PROFILE);
  
  // Catalog State
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);

  // Admin Credentials
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [loginError, setLoginError] = useState('');

  // State for saved invoices
  const [savedInvoices, setSavedInvoices] = useState<Invoice[]>([]);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);

  const handleLogin = () => {
    if (loginType === 'admin') {
      if (adminUser === 'boss' && adminPass === '8092') {
        setIsLoggedIn(true);
        setIsAdmin(true);
        setShowLoginModal(false);
        setActiveTab('admin');
        setLoginError('');
      } else {
        setLoginError('Invalid admin credentials');
      }
    } else if (loginType === 'register') {
      setBusinessProfile(BLANK_PROFILE);
      setIsLoggedIn(true);
      setIsAdmin(false);
      setShowLoginModal(false);
      setActiveTab('profile');
    } else {
      setIsLoggedIn(true);
      setIsAdmin(false);
      setShowLoginModal(false);
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
    setActiveTab('dashboard');
  };

  const handleSaveProfile = (updated: BusinessProfile) => {
    setBusinessProfile(updated);
  };

  const handleSaveInvoice = (invoice: Invoice) => {
    setSavedInvoices(prev => [invoice, ...prev]);
    // Increment auto-invoice number if enabled
    if (businessProfile.autoInvoiceConfig.enabled) {
      setBusinessProfile(prev => ({
        ...prev,
        autoInvoiceConfig: {
          ...prev.autoInvoiceConfig,
          nextNumber: prev.autoInvoiceConfig.nextNumber + 1
        }
      }));
    }
    setActiveTab('invoices');
  };

  const handleDeleteInvoice = (id: string) => {
    if (confirm("Are you sure you want to delete this invoice?")) {
      setSavedInvoices(prev => prev.filter(inv => inv.id !== id));
    }
  };

  const toggleMode = () => {
    if (isAdmin) {
      setActiveTab(activeTab === 'admin' ? 'dashboard' : 'admin');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar 
        isLoggedIn={isLoggedIn} 
        onLogin={() => {
          setLoginType('user');
          setShowLoginModal(true);
        }} 
        onLogout={handleLogout} 
      />
      
      <main className="flex-grow pb-24">
        {!isLoggedIn ? (
          <>
            <Hero />
            <section className="py-12 bg-white border-y border-gray-100">
              <div className="max-w-7xl mx-auto px-4 text-center">
                <p className="text-gray-500 font-semibold uppercase tracking-widest text-sm mb-8">Trusted by Industry Leaders</p>
                <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-50 grayscale">
                  <img src="https://picsum.photos/seed/brand1/120/40" alt="Brand 1" />
                  <img src="https://picsum.photos/seed/brand2/120/40" alt="Brand 2" />
                  <img src="https://picsum.photos/seed/brand3/120/40" alt="Brand 3" />
                  <img src="https://picsum.photos/seed/brand4/120/40" alt="Brand 4" />
                  <img src="https://picsum.photos/seed/brand5/120/40" alt="Brand 5" />
                </div>
              </div>
            </section>
            <Features />
          </>
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Sidebar Navigation */}
              <aside className="lg:w-64 flex-shrink-0">
                <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 p-4 space-y-2 sticky top-24">
                  {isAdmin && (
                    <button 
                      onClick={() => setActiveTab('admin')}
                      className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-black transition-all mb-4 ${
                        activeTab === 'admin' ? 'bg-green-600 text-white shadow-lg shadow-green-100' : 'bg-green-50 text-green-600 hover:bg-green-100'
                      }`}
                    >
                      <ShieldCheck className="w-5 h-5" /> Admin Panel
                    </button>
                  )}
                  
                  <button 
                    onClick={() => { setActiveTab('dashboard'); setViewingInvoice(null); }}
                    className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-black transition-all ${
                      activeTab === 'dashboard' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    <LayoutDashboard className="w-5 h-5" /> Dashboard
                  </button>
                  <button 
                    onClick={() => { setActiveTab('invoices'); setViewingInvoice(null); }}
                    className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-black transition-all ${
                      activeTab === 'invoices' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    <FileText className="w-5 h-5" /> All Invoices
                  </button>
                  <button 
                    onClick={() => { setActiveTab('customers'); setViewingInvoice(null); }}
                    className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-black transition-all ${
                      activeTab === 'customers' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    <Users className="w-5 h-5" /> Customers
                  </button>
                  <button 
                    onClick={() => { setActiveTab('profile'); setViewingInvoice(null); }}
                    className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-black transition-all ${
                      activeTab === 'profile' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    <UserCircle className="w-5 h-5" /> Business Profile
                  </button>
                  <div className="pt-4 mt-4 border-t border-gray-100">
                    <button 
                      onClick={() => setActiveTab('settings')}
                      className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-black transition-all ${
                        activeTab === 'settings' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      <Settings className="w-5 h-5" /> Settings
                    </button>
                  </div>
                </div>
              </aside>

              {/* Main Content Area */}
              <div className="flex-1 space-y-8">
                {activeTab === 'admin' && isAdmin ? (
                  <AdminPanel 
                    allInvoices={savedInvoices}
                    allCatalog={catalog}
                    currentProfile={businessProfile}
                  />
                ) : activeTab === 'dashboard' ? (
                  <>
                    <div className="flex justify-between items-end bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm">
                      <div>
                        <h1 className="text-3xl font-black text-gray-900">Welcome, {isAdmin ? 'Boss' : (businessProfile.businessName || 'New User')}</h1>
                        <p className="text-gray-500 font-medium">Ready to generate your next smart invoice?</p>
                      </div>
                      <div className="hidden md:block text-right">
                        <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Current Plan</p>
                        <p className="text-blue-600 font-black">{isAdmin ? 'System Administrator' : 'Premium Business'}</p>
                      </div>
                    </div>
                    <InvoiceGenerator 
                      businessProfile={businessProfile} 
                      onSaveInvoice={handleSaveInvoice}
                      onUpdateProfile={handleSaveProfile}
                      catalog={catalog}
                    />
                  </>
                ) : activeTab === 'invoices' ? (
                  viewingInvoice ? (
                    <div className="space-y-6 animate-fadeIn">
                      <button 
                        onClick={() => setViewingInvoice(null)}
                        className="flex items-center gap-2 text-blue-600 font-black hover:bg-blue-50 px-6 py-3 rounded-2xl transition-all"
                      >
                        <ArrowLeft className="w-5 h-5" /> Back to List
                      </button>
                      <TravelInvoiceTemplate invoice={viewingInvoice} profile={businessProfile} />
                    </div>
                  ) : (
                    <InvoiceList 
                      invoices={savedInvoices} 
                      onDelete={handleDeleteInvoice}
                      onView={setViewingInvoice}
                    />
                  )
                ) : activeTab === 'customers' ? (
                  <CustomerManagement />
                ) : activeTab === 'profile' ? (
                  <div className="space-y-8 animate-fadeIn">
                    <h1 className="text-3xl font-black text-gray-900">Manage Your Program</h1>
                    <BusinessProfileEditor profile={businessProfile} onSave={handleSaveProfile} />
                  </div>
                ) : activeTab === 'settings' ? (
                  <div className="space-y-8 animate-fadeIn">
                    <h1 className="text-3xl font-black text-gray-900">System Settings</h1>
                    <SettingsPanel 
                      profile={businessProfile} 
                      onSaveProfile={handleSaveProfile}
                      catalog={catalog}
                      onUpdateCatalog={setCatalog}
                    />
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        )}

        {/* Stats Section */}
        {!isLoggedIn && (
          <section className="py-20 bg-blue-600 text-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div>
                  <div className="text-4xl font-bold mb-2">1Cr+</div>
                  <div className="text-blue-100">Businesses</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">50Cr+</div>
                  <div className="text-blue-100">Invoices Created</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">4.7★</div>
                  <div className="text-blue-100">App Rating</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">24/7</div>
                  <div className="text-blue-100">Support</div>
                </div>
              </div>
            </div>
          </section>
        )}

        <FAQ />
      </main>

      <Footer />
      <ChatAssistant />

      {isLoggedIn && isAdmin && (
        <StatusSwitch isAdmin={activeTab === 'admin'} onToggle={toggleMode} />
      )}

      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-scaleIn">
            <div className="p-10">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-black text-gray-900">
                  {loginType === 'register' ? 'Create Account' : 'Login to myBillBook'}
                </h2>
                <button onClick={() => setShowLoginModal(false)} className="text-gray-400 hover:text-gray-600">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex p-1 bg-gray-100 rounded-2xl mb-8">
                <button 
                  onClick={() => setLoginType('user')}
                  className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${loginType === 'user' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}
                >
                  User Login
                </button>
                <button 
                  onClick={() => setLoginType('register')}
                  className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${loginType === 'register' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}
                >
                  Register
                </button>
                <button 
                  onClick={() => setLoginType('admin')}
                  className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${loginType === 'admin' ? 'bg-white text-green-600 shadow-sm' : 'text-gray-500'}`}
                >
                  Admin
                </button>
              </div>

              <div className="space-y-6">
                {(loginType === 'user' || loginType === 'register') ? (
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Mobile Number</label>
                    <div className="flex gap-2">
                      <span className="bg-gray-100 px-4 py-4 rounded-2xl text-gray-500 font-bold">+91</span>
                      <input 
                        type="tel" 
                        placeholder="Enter 10 digit number"
                        className="flex-1 bg-gray-50 border-2 border-gray-100 rounded-2xl px-6 py-4 focus:border-blue-500 outline-none transition-all font-bold"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Username</label>
                      <div className="relative">
                        <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input 
                          type="text" 
                          value={adminUser}
                          onChange={(e) => setAdminUser(e.target.value)}
                          placeholder="Enter admin username"
                          className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl pl-12 pr-6 py-4 focus:border-green-500 outline-none transition-all font-bold"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Password</label>
                      <div className="relative">
                        <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input 
                          type="password" 
                          value={adminPass}
                          onChange={(e) => setAdminPass(e.target.value)}
                          placeholder="Enter admin password"
                          className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl pl-12 pr-6 py-4 focus:border-green-500 outline-none transition-all font-bold"
                        />
                      </div>
                    </div>
                    {loginError && <p className="text-red-500 text-xs font-bold text-center">{loginError}</p>}
                  </div>
                )}

                <button 
                  onClick={handleLogin}
                  className={`w-full py-5 rounded-2xl font-black flex items-center justify-center gap-2 transition-all shadow-lg ${
                    loginType === 'admin' ? 'bg-green-600 hover:bg-green-700 text-white shadow-green-100' : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-100'
                  }`}
                >
                  {loginType === 'register' ? <UserPlus className="w-5 h-5" /> : <LogIn className="w-5 h-5" />}
                  {loginType === 'register' ? 'Create Fresh Profile' : loginType === 'admin' ? 'Access Admin Panel' : 'Login & Start Billing'}
                </button>
                
                <p className="text-center text-xs text-gray-400 font-medium">
                  By logging in, you agree to our <span className="text-blue-600 cursor-pointer">Terms & Conditions</span>
                </p>
              </div>
            </div>
            <div className="bg-gray-50 p-8 text-center border-t border-gray-100">
              <p className="text-gray-600 font-medium">
                {loginType === 'register' ? 'Already have an account?' : 'New to myBillBook?'} 
                <span 
                  className="text-blue-600 font-black cursor-pointer ml-1"
                  onClick={() => setLoginType(loginType === 'register' ? 'user' : 'register')}
                >
                  {loginType === 'register' ? 'Login' : 'Create Account'}
                </span>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
