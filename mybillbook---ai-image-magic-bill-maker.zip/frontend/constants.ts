
import { FAQItem, Feature, Testimonial, BusinessProfile } from './types';

export const BLANK_PROFILE: BusinessProfile = {
  businessName: "",
  gstin: "",
  panNumber: "",
  msmeNumber: "",
  address: "",
  phone: "",
  email: "",
  logoUrl: "",
  upiId: "",
  autoInvoiceConfig: {
    enabled: true,
    prefix: "INV-",
    nextNumber: 101
  },
  travelFieldConfig: {
    showDateOfJourney: true,
    showDriverName: true,
    showPickupLocation: true,
    showDropLocation: true,
    showTripType: true,
    showCabNumber: true
  },
  bankDetails: {
    name: "",
    ifsc: "",
    accountNo: "",
    bankName: ""
  }
};

export const DEFAULT_PROFILE: BusinessProfile = {
  businessName: "DHARMA CAR TRAVELS",
  gstin: "20BRDPM9402P1ZN",
  panNumber: "AAXFD2354D",
  msmeNumber: "UDYAM-JH-04-0025087",
  address: "NA, COURT MORE, NEAR DHANBAD POST OFFICE COURT MORE, Dhanbad, Jharkhand, 826001",
  phone: "7004621221",
  email: "justcallcab24@gmail.com",
  logoUrl: "https://picsum.photos/seed/travel/200/200",
  upiId: "dharma@upi",
  autoInvoiceConfig: {
    enabled: true,
    prefix: "DCT",
    nextNumber: 268
  },
  travelFieldConfig: {
    showDateOfJourney: true,
    showDriverName: true,
    showPickupLocation: true,
    showDropLocation: true,
    showTripType: true,
    showCabNumber: true
  },
  bankDetails: {
    name: "DHARMA CAR TRAVELS",
    ifsc: "IBKL0001915",
    accountNo: "1915102000007245",
    bankName: "IDBI, BARTAND"
  }
};

export const FAQS: FAQItem[] = [
  {
    question: "What is billing software?",
    answer: "Billing software is a digital tool that helps businesses to automate and streamline their billing and invoicing processes. It includes features like invoice generation, inventory management, and payment tracking."
  },
  {
    question: "Which billing software is best for small businesses?",
    answer: "myBillBook is designed specifically for Indian SMBs, offering a user-friendly interface, GST compliance, and mobile-desktop sync, making it the top choice for over 1 Crore businesses."
  },
  {
    question: "What are the top features of a GST billing software?",
    answer: "Key features include GST/non-GST bill generation, inventory management, e-invoicing, e-way billing, business reports, and automated payment reminders."
  },
  {
    question: "Can I have a free trial of myBillBook app?",
    answer: "Yes, new users can enjoy a free trial by registering with their mobile number to explore all premium features."
  }
];

export const FEATURES: Record<string, Feature[]> = {
  Billing: [
    {
      id: 'b1',
      title: 'GST Invoicing',
      description: 'Create professional GST bills in less than 8 seconds.',
      icon: 'FileText',
      image: 'https://picsum.photos/seed/billing1/600/400'
    },
    {
      id: 'b2',
      title: 'POS Billing',
      description: 'Fast checkout experience for retail counters.',
      icon: 'ShoppingCart',
      image: 'https://picsum.photos/seed/billing2/600/400'
    }
  ],
  Inventory: [
    {
      id: 'i1',
      title: 'Stock Management',
      description: 'Track inventory levels in real-time across multiple godowns.',
      icon: 'Package',
      image: 'https://picsum.photos/seed/inv1/600/400'
    },
    {
      id: 'i2',
      title: 'Low Stock Alerts',
      description: 'Get notified before you run out of essential items.',
      icon: 'AlertTriangle',
      image: 'https://picsum.photos/seed/inv2/600/400'
    }
  ]
};

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "Amar Singh",
    business: "Hardware Store Owner",
    content: "myBillBook has revolutionized how I manage my hardware business. Inventory tracking is now effortless.",
    avatar: "https://picsum.photos/seed/user1/100/100"
  },
  {
    id: 2,
    name: "Priya Sharma",
    business: "FMCG Distributor",
    content: "The e-invoicing feature is a lifesaver. One click and my compliance is sorted!",
    avatar: "https://picsum.photos/seed/user2/100/100"
  }
];
