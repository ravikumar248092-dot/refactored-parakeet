
import { GoogleGenAI, Type } from '@google/genai';
import { Invoice, LedgerUpdate } from '../types';

const API_KEY = (process.env as any).API_KEY;

export interface AIExtractionResult {
  invoice: Invoice;
  detectedBusinessName?: string;
  detectedAddress?: string;
}

export class GeminiService {
  private ai: any;

  constructor() {
    if (!API_KEY) {
      console.warn("API_KEY is missing. AI features will be disabled.");
      return;
    }
    this.ai = new GoogleGenAI({ apiKey: API_KEY, vertexai: true });
  }

  async getBillingAdvice(query: string): Promise<string> {
    if (!this.ai) return "AI Assistant is currently unavailable.";

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          role: 'user',
          parts: [{ text: query }]
        },
        config: {
          systemInstruction: "You are an expert in Indian GST laws and small business accounting. You help users of myBillBook software.",
          temperature: 0.7,
        }
      });

      return response.text || "I'm sorry, I couldn't process that request.";
    } catch (error) {
      console.error("Gemini API Error:", error);
      return "An error occurred while fetching AI advice.";
    }
  }

  async analyzeSystemData(dataSummary: string): Promise<string> {
    if (!this.ai) return "AI Analysis unavailable.";

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          role: 'user',
          parts: [{ text: `Analyze this system database summary and provide a "Boss Report". 
          Suggest optimizations for the "Setup Store" (configurations) and identify business trends.
          Data Summary: ${dataSummary}` }]
        },
        config: {
          systemInstruction: "You are the AI System Architect for the Boss. Provide high-level strategic insights and database optimization suggestions.",
          temperature: 0.5,
        }
      });

      return response.text || "Analysis complete. No critical issues found.";
    } catch (error) {
      console.error("AI Analysis Error:", error);
      return "Error during AI system analysis.";
    }
  }

  async generateInvoiceData(prompt: string): Promise<Invoice | null> {
    if (!this.ai) return null;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          role: 'user',
          parts: [{ text: `Extract invoice details from this request: "${prompt}". 
          If it's a travel or cab booking, extract: driverName, cabNumber, pickupLocation, dropLocation, tripType, dateOfJourney.
          Return structured JSON.` }]
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              customerName: { type: Type.STRING },
              date: { type: Type.STRING },
              invoiceNumber: { type: Type.STRING },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    description: { type: Type.STRING },
                    quantity: { type: Type.NUMBER },
                    price: { type: Type.NUMBER },
                    gstRate: { type: Type.NUMBER }
                  },
                  required: ['description', 'quantity', 'price', 'gstRate']
                }
              },
              totalAmount: { type: Type.NUMBER },
              totalGst: { type: Type.NUMBER },
              receivedAmount: { type: Type.NUMBER },
              balanceAmount: { type: Type.NUMBER },
              travelDetails: {
                type: Type.OBJECT,
                properties: {
                  dateOfJourney: { type: Type.STRING },
                  driverName: { type: Type.STRING },
                  pickupLocation: { type: Type.STRING },
                  dropLocation: { type: Type.STRING },
                  tripType: { type: Type.STRING },
                  cabNumber: { type: Type.STRING },
                  totalKm: { type: Type.STRING }
                }
              }
            },
            required: ['customerName', 'date', 'items', 'invoiceNumber', 'totalAmount', 'totalGst']
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Invoice Generation Error:", error);
      return null;
    }
  }

  async refineInvoiceWithAI(currentInvoice: Invoice, instruction: string): Promise<Invoice | null> {
    if (!this.ai) return null;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          role: 'user',
          parts: [{ text: `Update this invoice data: ${JSON.stringify(currentInvoice)} based on this instruction: "${instruction}". 
          Common requests include changing the driver name, updating quantities, or fixing the customer name. 
          Return the full updated invoice as structured JSON.` }]
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              customerName: { type: Type.STRING },
              date: { type: Type.STRING },
              invoiceNumber: { type: Type.STRING },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    description: { type: Type.STRING },
                    quantity: { type: Type.NUMBER },
                    price: { type: Type.NUMBER },
                    gstRate: { type: Type.NUMBER }
                  }
                }
              },
              totalAmount: { type: Type.NUMBER },
              totalGst: { type: Type.NUMBER },
              receivedAmount: { type: Type.NUMBER },
              balanceAmount: { type: Type.NUMBER },
              travelDetails: {
                type: Type.OBJECT,
                properties: {
                  dateOfJourney: { type: Type.STRING },
                  driverName: { type: Type.STRING },
                  pickupLocation: { type: Type.STRING },
                  dropLocation: { type: Type.STRING },
                  tripType: { type: Type.STRING },
                  cabNumber: { type: Type.STRING },
                  totalKm: { type: Type.STRING }
                }
              }
            }
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Invoice Refinement Error:", error);
      return null;
    }
  }

  async extractInvoiceFromImage(base64Data: string, mimeType: string): Promise<AIExtractionResult | null> {
    if (!this.ai) return null;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          role: 'user',
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType
              }
            },
            {
              text: "Extract all data from this invoice image into a structured JSON format. Also, identify the SELLER'S business name and address from the header of the bill. Include customerName, date, invoiceNumber, items (description, quantity, price, gstRate), totalAmount, totalGst, receivedAmount, balanceAmount, travelDetails, detectedBusinessName (the seller), and detectedAddress (the seller)."
            }
          ]
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              customerName: { type: Type.STRING },
              date: { type: Type.STRING },
              invoiceNumber: { type: Type.STRING },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    description: { type: Type.STRING },
                    quantity: { type: Type.NUMBER },
                    price: { type: Type.NUMBER },
                    gstRate: { type: Type.NUMBER }
                  }
                }
              },
              totalAmount: { type: Type.NUMBER },
              totalGst: { type: Type.NUMBER },
              receivedAmount: { type: Type.NUMBER },
              balanceAmount: { type: Type.NUMBER },
              travelDetails: {
                type: Type.OBJECT,
                properties: {
                  dateOfJourney: { type: Type.STRING },
                  driverName: { type: Type.STRING },
                  pickupLocation: { type: Type.STRING },
                  dropLocation: { type: Type.STRING },
                  tripType: { type: Type.STRING },
                  cabNumber: { type: Type.STRING },
                  totalKm: { type: Type.STRING }
                }
              },
              detectedBusinessName: { type: Type.STRING },
              detectedAddress: { type: Type.STRING }
            }
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Image Extraction Error:", error);
      return null;
    }
  }

  async parseLedgerEntry(prompt: string): Promise<LedgerUpdate | null> {
    if (!this.ai) return null;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          role: 'user',
          parts: [{ text: `Parse this business transaction: "${prompt}". Identify the customer name, amount, and whether it is a payment received (PAID) or a credit sale/due (DUE).` }]
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              customerName: { type: Type.STRING },
              amount: { type: Type.NUMBER },
              type: { type: Type.STRING, enum: ['PAID', 'DUE'] },
              description: { type: Type.STRING }
            },
            required: ['customerName', 'amount', 'type', 'description']
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Ledger Parsing Error:", error);
      return null;
    }
  }
}

export const geminiService = new GeminiService();
