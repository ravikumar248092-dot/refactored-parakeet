
export interface FAQItem {
  question: string;
  answer: string;
}

export interface Feature {
  id: string;
  title: string;
  description: string;
  icon: string;
  image: string;
}

export interface Testimonial {
  id: number;
  name: string;
  business: string;
  content: string;
  avatar: string;
}

export interface LineItem {
  description: string;
  quantity: number;
  price: number;
  gstRate: number;
}

export interface TravelDetails {
  dateOfJourney?: string;
  driverName?: string;
  pickupLocation?: string;
  dropLocation?: string;
  tripType?: string;
  cabNumber?: string;
  totalKm?: string;
}

export interface Invoice {
  id: string;
  customerName: string;
  date: string;
  items: LineItem[];
  invoiceNumber: string;
  totalAmount: number;
  totalGst: number;
  receivedAmount?: number;
  balanceAmount?: number;
  travelDetails?: TravelDetails;
}

export interface CatalogItem {
  id: string;
  name: string;
  price: number;
  gstRate: number;
  category: string;
}

export interface AutoInvoiceConfig {
  enabled: boolean;
  prefix: string;
  nextNumber: number;
}

export interface TravelFieldConfig {
  showDateOfJourney: boolean;
  showDriverName: boolean;
  showPickupLocation: boolean;
  showDropLocation: boolean;
  showTripType: boolean;
  showCabNumber: boolean;
}

export interface BusinessProfile {
  businessName: string;
  gstin: string;
  panNumber?: string;
  msmeNumber?: string;
  address: string;
  phone: string;
  email: string;
  logoUrl?: string;
  upiId?: string;
  autoInvoiceConfig: AutoInvoiceConfig;
  travelFieldConfig: TravelFieldConfig;
  bankDetails?: {
    name: string;
    ifsc: string;
    accountNo: string;
    bankName: string;
  };
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  totalDues: number;
  totalPaid: number;
}

export interface Transaction {
  id: string;
  customerId: string;
  amount: number;
  type: 'PAID' | 'DUE';
  date: string;
  description: string;
}

export interface LedgerUpdate {
  customerName: string;
  amount: number;
  type: 'PAID' | 'DUE';
  description: string;
}
